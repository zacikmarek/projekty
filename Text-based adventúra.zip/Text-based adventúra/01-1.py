# Marek Zacik
# 01.01.2018
# Text-based adventure game 0.1 Alpha

import random
import time

def displayIntro():
    print('''Hello stranger.
Welcome to my first game ever.
In this game you will need to guess, which way is best for you to survive!
Do you think that you can survive to the end?
We will see...
Muhahahaha ''')
print()

def choosePath():
    path = ''
    while path != '1' and path != '2':
        print('Which door will you open? (1 or 2)')
        path = input()
    return path

def checkPath(chosenPath):
    print('You approach the chosen door...')
    time.sleep(2)
    print('It was not a great choise, but still better than the second door.')
    time.sleep(2)
    print('This room is dark, without light. You need to use your flashlight.')
    time.sleep(2)
    print('Lets just hope that you have some batteries in it.')
    time.sleep(2)
    print('You can hear some weird noises, you are scared...')
    time.sleep(2)
    print('But somehow you managed to find a hole in the wall and pass trought it.')
    time.sleep(2)

    safePath = random.randint(1,2)

    if chosenPath == str(safePath):
        print('You managed to survive first test and now you need to choose again!')
    else:
        print('You entered wrong doors. You heard lock sound and you are in a room will zombies...')
        print('This is you end.')

playAgain = 'yes'
while playAgain == 'yes' or playAgain == 'y':
    displayIntro()
    pathNumber = choosePath()
    checkPath(pathNumber)

    print('Do you want to play again? (yes or no) ')
    playAgain = input()


