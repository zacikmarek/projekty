# Marek Zacik
# 01.01.2018
# Text-based adventure game 0.2 Beta

import random
import time

def displayIntro():
    print('''Hello stranger.
Welcome to my first game ever.
In this game you will need to guess, which way is best for you to survive!
Do you think that you can survive to the end?
We will see...
Muhahahaha ''')
print()

def choosePath():
    path = ''
    while path != '1' and path != '2':
        print('Which door will you open? (1 or 2)')
        path = input()

    return path

def checkPath(chosenPath):
    print('You approach the chosen door...')
    time.sleep(2)
    print('It was not a great choise, but maybe it is better choise than the second door.')
    time.sleep(2)
    print('This room is dark, without light. You need to use your flashlight.')
    time.sleep(2)
    print('Lets just hope that you have some batteries in it.')
    time.sleep(2)
    print('You can hear some weird noises, you are scared...')
    time.sleep(2)

    safePath = random.randint(1,2)

    if chosenPath == str(safePath):
        print('But somehow you managed to find a hole in the wall and pass trought it.')
        print('You managed to survive first test and now you need to choose again!')
        choosePath()           
        print('You chosed that nicer looking doors, lets hope it was a good choise.')
        time.sleep(2)
        print('There was something on the floor.')
        time.sleep(2)
        print('You used your flashlight to check what is that.')
        time.sleep(2)
        print('It was... a... blood....')
        time.sleep(2)
        print('You started running until you found a doors.')
        time.sleep(2)
        print('There was a huge text next to them.')
        time.sleep(2)
        print('The text was saying...')
        time.sleep(1)
        print('Behind me is a key... maybe')

        safePath = random.randint(1,2)

        if chosenPath == str(safePath):
            print('You tried your luck')
            time.sleep(2)
            print('You was lucky, there was a key!')
            time.sleep(1)
            print('You opened that door and now you are standing in front of last pair of doors.')
            time.sleep(1)
            print('Choose carefull.')
            choosePath()
            print('Last door, last chance to die.. But we will see if you are lucky today.')
            time.sleep(2)
            print('There was playing piano in this room. It was kinda creepy')
            time.sleep(2)
            print('You aimed your flashlight there but you saw just piano, nobody was playing on it.')
            time.sleep(2)
            print('Do you believe in ghosts?... Now you shoud start to believe.. Hahaha')
            time.sleep(2)
            print('You started to slowly walking to the piano.')
            time.sleep(2)
            print('There was a papper on the key...')
            time.sleep(2)
            print('Text says:')
            time.sleep(1)
            print('If you can play this piano and create a Justin Bieber - Baby tone, you will survive!')
            time.sleep(2)
            print('You know that you need to do it.')
            time.sleep(1)
            print('So you started to play that melody...')
            time.sleep(1)
            print('*MONOLOG*.. Shoud I play on the right side of piano or left?')

            safePath = random.randint(1,2)

            if chosenPath == str(safePath):
                print('You did it! You played melody of Baby.. That means just two things...')
                time.sleep(2)
                print('First one:')
                time.sleep(1)
                print('You are a gay...')
                time.sleep(1)
                print('And the second thing.. much more important..')
                time.sleep(2)
                print('You saved your ass, you won this game!')
                time.sleep(1)
                print('And the prize is...')
                time.sleep(2)
                print('Error 404. Prize not found...')
                time.sleep(1)
                print('HAHAHAHA')


            else:
                print('You are wrong! You played melody of something else than Baby.. That means just two things...')
                time.sleep(2)
                print('First one:')
                time.sleep(1)
                print('You are not a gay...')
                time.sleep(1)
                print('And the second thing.. much more important..')
                time.sleep(2)
                print('You lost!')
                time.sleep(1)
                print('Ghost is coming for you.')
                time.sleep(1)
                print('HAHAHA')
                
            

        else:
            print('You tried your luck')
            time.sleep(2)
            print('So unlucky, there was not a key behind that text.')
            time.sleep(2)
            print('Now a zombie aproach you from behind and....')
            time.sleep(2)
            print('This is your end.')      
        

    else:
        print('You entered wrong doors. You heard lock sound and you are in a room will zombies...')
        print('This is your end.')

    
playAgain = 'yes'
while playAgain == 'yes' or playAgain == 'y':
    displayIntro()
    pathNumber = choosePath()
    checkPath(pathNumber)

    print('Do you want to play again? (yes or no) ')
    playAgain = input()
